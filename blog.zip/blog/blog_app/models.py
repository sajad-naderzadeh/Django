from abc import abstractmethod

from django.contrib.auth import get_user_model
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime


User = get_user_model()


# Create your models here.


class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))
    is_active = models.BooleanField(default=True, verbose_name=_('Is Active'))

    class Meta:
        abstract = True

    @abstractmethod
    def __str__(self):
        pass

    @property
    def created_at_humanized(self):
        return naturaltime(self.created_at)

    created_at_humanized.fget.short_description = _('Created at')

    @property
    def updated_at_humanized(self):
        return naturaltime(self.updated_at)

    updated_at_humanized.fget.short_description = _('Updated at')


class BaseModelWithTitleAndDescription(BaseModel):
    title = models.CharField(max_length=255, unique=True, verbose_name=_("Title"))
    description = models.TextField(default='', verbose_name=_("Description"))

    class Meta:
        abstract = True

    def __str__(self):
        return self.title


class BaseModelWithSlug(BaseModel):
    slug = models.SlugField(max_length=255, unique=True, verbose_name=_("Slug"))

    class Meta:
        abstract = True

    @abstractmethod
    def __str__(self):
        pass


class Category(BaseModelWithTitleAndDescription, BaseModelWithSlug):
    slug = models.SlugField(max_length=255, unique=True, verbose_name=_("Slug"))

    class Meta:
        verbose_name = _("Category")
        verbose_name_plural = _("Categories")

    def __str__(self):
        return self.title

    def all_posts(self):
        return self.posts.all()

    @property
    def post_count(self):
        return self.posts.count()

    @property
    def active_post_count(self):
        return self.posts.filter(is_active=True).count()


class Tag(BaseModel):
    name = models.CharField(max_length=255, unique=True, verbose_name=_("Name"))
    slug = models.SlugField(max_length=255, unique=True, verbose_name=_("Slug"))

    class Meta:
        verbose_name = _("Tag")
        verbose_name_plural = _("Tags")

    def __str__(self):
        return self.name


class Post(BaseModelWithTitleAndDescription, BaseModelWithSlug):
    category = models.ForeignKey(Category, related_name='posts', on_delete=models.PROTECT, verbose_name=_("Category"))
    author = models.ForeignKey(User, related_name='posts', on_delete=models.PROTECT, verbose_name=_("Author"))

    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))
    is_active = models.BooleanField(default=False, verbose_name=_('Is Active'))

    class Meta:
        verbose_name = _("Post")
        verbose_name_plural = _("Posts")

    def __str__(self):
        return self.title


class Comment(BaseModel):
    post = models.ForeignKey(Post, related_name='comments', on_delete=models.PROTECT, verbose_name=_("Post"))
    author = models.ForeignKey(User, related_name='comments', on_delete=models.PROTECT, verbose_name=_("Author"))
    comment = models.CharField(max_length=255, unique=True, verbose_name=_("Comment"))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _("Comment")
        verbose_name_plural = _("Comments")

    def __str__(self):
        return self.comment
