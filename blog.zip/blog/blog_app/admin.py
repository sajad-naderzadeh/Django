from django.contrib import admin
from .models import (
    Category,
    Tag,
    Post,
    Comment,
)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'post_count', 'active_post_count', 'is_active', 'created_at_humanized',
                    'updated_at_humanized')
    list_display_links = ('id', 'title')
    list_filter = ('created_at', 'updated_at', 'is_active',)
    search_fields = ('title', 'description')
    list_editable = ('is_active',)


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'slug', 'created_at_humanized', 'updated_at_humanized')
    list_display_links = ('id', 'name')
    list_filter = ('created_at', 'updated_at',)
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'category', 'author', 'title', 'is_active', 'created_at_humanized', 'updated_at_humanized')
    list_display_links = ('id', 'category', 'author', 'title')
    list_filter = ('created_at', 'updated_at', 'is_active', 'category', 'author',)
    search_fields = ('title', 'description')
    list_editable = ('is_active',)


@admin.register(Comment)
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'post', 'comment', 'updated_at_humanized')
    list_display_links = ('id', 'post', 'comment')
    list_filter = ('created_at', 'updated_at')
    search_fields = ('comment', 'post__title', 'post__description')

