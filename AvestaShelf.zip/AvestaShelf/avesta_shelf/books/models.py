from django.db import models
from django.db.models import Avg
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime
from django.utils.html import format_html


# Create your models here.


class Publisher(models.Model):
    title = models.CharField(max_length=255, unique=True, verbose_name=_('Title'))
    address = models.TextField(verbose_name=_('Address'))
    establish = models.PositiveSmallIntegerField(verbose_name=_('Establishment'))
    description = models.TextField(verbose_name=_('Description'), blank=True)
    email = models.EmailField(verbose_name=_('Email'), blank=True)
    phone_number = models.CharField(max_length=20, verbose_name=_('Phone number'), blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))
    thumbnail = models.ImageField(upload_to="books/publisher/thumbnail/", verbose_name=_('Thumbnail'))

    class Meta:
        verbose_name = _('Publisher')
        verbose_name_plural = _('Publishers')

    def __str__(self):
        return self.title

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def thumbnail_tag(self):
        if self.thumbnail:
            url = self.thumbnail.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    thumbnail_tag.fget.short_description = _('Thumbnail')


class Writer(models.Model):
    first_name = models.CharField(max_length=50, verbose_name=_('First name'))
    last_name = models.CharField(max_length=50, verbose_name=_('Last name'))
    personal_image = models.ImageField(upload_to="books/writer/personal_image/", blank=True, null=True,
                                       verbose_name=_('personal_image'))
    birth_date = models.DateField(verbose_name=_('Birth date'))
    biography = models.TextField(verbose_name=_('Biography'), blank=True)
    nick_name = models.CharField(max_length=50, verbose_name=_('Nick name'), blank=True)
    brith_city = models.CharField(max_length=50, verbose_name=_('Brith city'), blank=True)
    brith_country = models.CharField(max_length=50, verbose_name=_('Brith country'), blank=True)
    date_of_dead = models.DateField(verbose_name=_('Date of dead'), null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Writer')
        verbose_name_plural = _('Writers')

    def __str__(self):
        return f'{self.first_name} {self.last_name}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

    @property
    def personal_image_tag(self):
        if self.personal_image:
            url = self.personal_image.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    personal_image_tag.fget.short_description = _('Personal image')


class Category(models.Model):
    title = models.CharField(max_length=255, unique=True, verbose_name=_('Title'))
    address = models.CharField(max_length=200, verbose_name=_('Address'), blank=True, null=True)
    description = models.TextField(verbose_name=_('Description'), blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Category')
        verbose_name_plural = _('Categories')

    def __str__(self):
        return self.title

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)


class Book(models.Model):
    title = models.CharField(max_length=255, unique=True, verbose_name=_('Title'))
    description = models.TextField(verbose_name=_('Description'), blank=True)
    publish_year = models.PositiveSmallIntegerField(verbose_name=_('Publish year'))
    publisher = models.ForeignKey(Publisher, verbose_name=_('Publisher'), on_delete=models.CASCADE)
    number_of_pages = models.PositiveSmallIntegerField(verbose_name=_('Number of pages'))
    isbn = models.CharField(max_length=20, verbose_name=_('ISBN'), blank=True)
    thumbnail = models.ImageField(upload_to="books/book/thumbnail/", verbose_name=_('Thumbnail'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Book')
        verbose_name_plural = _('Books')
        unique_together = (('publisher', 'title'),)

    def __str__(self):
        return self.title

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def thumbnail_tag(self):
        if self.thumbnail:
            url = self.thumbnail.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    thumbnail_tag.fget.short_description = _('Thumbnail')

    @property
    def categories(self):
        return ', '.join(
            [book_category.category.title for book_category in self.books_categories.select_related('category').all()])

    @property
    def writers(self):
        return ', '.join(
            [book_writer.writer.full_name for book_writer in self.books_writers.select_related('writer').all()])

    @property
    def rating_count(self):
        return self.book_ratings.count()

    @property
    def score(self):
        result = self.book_ratings.aggregate(avg_score=Avg('score'))
        return result['avg_score'] or 0

    @property
    def ratings(self):
        return self.book_ratings.all()

    @property
    def is_available(self):
        return self.lendings.exclude(is_returned=False).exists()


class BookCategory(models.Model):
    category = models.ForeignKey(Category, related_name="books_categories", verbose_name=_('Category'),
                                 on_delete=models.CASCADE)
    book = models.ForeignKey(Book, related_name="books_categories", verbose_name=_('Book'), on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Book Category')
        verbose_name_plural = _('Book Categories')
        unique_together = (('category', 'book'),)

    def __str__(self):
        return f'{self.book} - {self.category}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)


class BookWriter(models.Model):
    writer = models.ForeignKey(Writer, related_name="books_writers", verbose_name=_('Writer'), on_delete=models.CASCADE)
    book = models.ForeignKey(Book, related_name="books_writers", verbose_name=_('Book'), on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Book Writer')
        verbose_name_plural = _('Book Writers')
        unique_together = (('writer', 'book'),)

    def __str__(self):
        return f'{self.book} - {self.writer}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)


class BookImage(models.Model):
    book = models.ForeignKey(Book, related_name="books_images", verbose_name=_('Book'), on_delete=models.CASCADE)
    image = models.ImageField(upload_to="books/book/images/", verbose_name=_('Image'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Book Image')
        verbose_name_plural = _('Book Images')

    def __str__(self):
        return f'{self.book} - {self.image}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def thumbnail_tag(self):
        if self.image:
            url = self.image.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    thumbnail_tag.fget.short_description = _('Thumbnail')
