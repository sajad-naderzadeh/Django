from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import (
    Publisher,
    Writer,
    Category,
    Book,
    BookCategory,
    BookWriter,
    BookImage
)


class BookCategoryInLine(admin.TabularInline):
    model = BookCategory
    extra = 1


class BookWriterInLine(admin.TabularInline):
    model = BookWriter
    extra = 1


class BookImageInLine(admin.TabularInline):
    model = BookImage
    extra = 1


@admin.register(Publisher)
class PublisherAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'thumbnail_tag',
        'title',
        'establish',
        'email',
        'phone_number',
        'created_at_humanize',
        'updated_at_humanize'
    )
    list_display_links = (
        'id',
        'title',
        'establish',
    )
    list_filter = (
        'created_at',
        'updated_at',
        'establish',
    )
    list_search_fields = ('title', 'description', 'email', 'phone_number')


@admin.register(Writer)
class WriterAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'first_name',
        'last_name',
        'personal_image_tag',
        'birth_date',
        'nick_name',
        'brith_city',
        'brith_country',
        'date_of_dead',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'first_name',
        'last_name',
    )
    list_filter = (
        'created_at',
        'updated_at',
        'birth_date',
        'date_of_dead',
        'brith_city',
        'brith_country',

    )
    search_fields = ('first_name', 'last_name')


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'title',
        'address',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'title'
    )
    list_filter = (
        'created_at',
        'updated_at',
    )
    search_fields = ('title', 'description')


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'thumbnail_tag',
        'title',
        'categories',
        'writers',
        'publish_year',
        'publisher',
        'number_of_pages',
        'rating_count',
        'score',
        'isbn',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'title',
        'publisher'
    )
    list_filter = (
        'created_at',
        'updated_at',
    )
    search_fields = (
        'title',
        'description',
        'isbn',
    )
    inlines = (
        BookCategoryInLine,
        BookWriterInLine,
        BookImageInLine,
    )


@admin.register(BookCategory)
class BookCategoryAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'category',
        'book',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'category',
    )
    list_filter = (
        'book',
        'created_at',
        'updated_at',
    )
    search_fields = (
        'category__title',
        'category__description',
        'book__title',
        'book__description',
        'book__isbn',
    )


@admin.register(BookWriter)
class BookWriterAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'writer',
        'book',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'writer',
    )
    list_filter = (
        'created_at',
        'updated_at',
    )
    search_fields = (
        'writer__first_name',
        'writer__last_name',
        'book__title',
        'book__description',
        'book__isbn',
    )


@admin.register(BookImage)
class BookImageAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'book',
        'thumbnail_tag',
        'created_at_humanize',
        'updated_at_humanize',
    )
    list_display_links = (
        'id',
        'book',
    )
    list_filter = (
        'created_at',
        'updated_at',
    )
    search_fields = (
        'book__title',
        'book__description',
        'book__isbn',
        'image'
    )