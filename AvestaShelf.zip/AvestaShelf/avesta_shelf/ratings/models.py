from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime

from books.models import Book

User = get_user_model()


# Create your models here.


class BookRating(models.Model):
    book = models.ForeignKey(Book, related_name='book_ratings', on_delete=models.CASCADE, verbose_name=_('Book'))
    user = models.ForeignKey(User, related_name='book_ratings', on_delete=models.CASCADE, verbose_name=_('User'))
    score = models.PositiveSmallIntegerField(
        default=5,
        validators=[MaxValueValidator(5), MinValueValidator(1)],
        verbose_name=_('Score')
    )
    comment = models.TextField(blank=True, verbose_name=_('Comment'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Book Rating')
        verbose_name_plural = _('Book Ratings')

    def __str__(self):
        return f'{self.score} - {self.comment}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)
