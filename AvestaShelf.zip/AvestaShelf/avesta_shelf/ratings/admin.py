from django.contrib import admin
from .models import BookRating


# Register your models here.


@admin.register(BookRating)
class BookRatingAdmin(admin.ModelAdmin):
    list_display = ('id', 'book', 'user', 'score', 'comment', 'created_at_humanize', 'updated_at_humanize')
    list_display_links = ('id', 'book', 'user')
    list_filter = ('created_at', 'updated_at', 'score')
    search_fields = ('book__title', 'book__description', 'book__isbn', 'comment')

