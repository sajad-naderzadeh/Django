
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    model = User
    list_display = (
        'username',
        'email',
        'national_id',
        'phone_number',
        'role',
        'is_active',
        'joined_at_humanize',
    )
    list_filter = (
        'role',
        'is_active',
        'joined_at',
    )
    search_fields = (
        'username',
        'email',
        'national_id',
        'phone_number',
    )
    readonly_fields = (
        'joined_at',
        'updated_at',
    )

    ordering = ('-joined_at',)

    def get_queryset(self, request):
        return super().get_queryset(request)
