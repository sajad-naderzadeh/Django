from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime


class User(AbstractUser):
    class Role(models.TextChoices):
        MEMBER = 'member', _('Member')
        LIBRARIAN = 'librarian', _('Librarian')
        ADMIN = 'admin', _('Admin')

    email = models.EmailField(
        _('Email address'),
        unique=True,
        help_text=_('Required. A valid email address.')
    )
    national_id = models.CharField(
        _('National ID'),
        max_length=20,
        unique=True,
        null=True,
        blank=True,
        help_text=_('User national identification number')
    )
    phone_number = models.CharField(
        _('Phone number'),
        max_length=20,
        null=True,
        blank=True,
        help_text=_('User contact phone number')
    )
    address = models.TextField(
        _('Address'),
        blank=True,
        help_text=_('User residential address')
    )
    role = models.CharField(
        _('Role'),
        max_length=20,
        choices=Role.choices,
        default=Role.MEMBER,
        help_text=_('Role of the user in the system'),
    )
    joined_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('Joined at')
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_('Updated at')
    )
    is_active = models.BooleanField(
        _('Active'),
        default=True,
        help_text=_('Designates whether this user should be treated as active.')
    )
    # Override reverse accessors to avoid clashes
    groups = models.ManyToManyField(
        Group,
        verbose_name=_('groups'),
        blank=True,
        help_text=_('The groups this user belongs to.'),
        related_name='custom_user_set',
        related_query_name='user',
    )
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('user permissions'),
        blank=True,
        help_text=_('Specific permissions for this user.'),
        related_name='custom_user_set',
        related_query_name='user',
    )

    class Meta:
        verbose_name = _('User')
        verbose_name_plural = _('Users')
        ordering = ['-joined_at']

    def __str__(self):
        return f'{self.username} ({self.get_role_display()})'

    @property
    def joined_at_humanize(self):
        return naturaltime(self.joined_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    def deactivate(self):
        self.is_active = False
        self.save(update_fields=['is_active'])

    def activate(self):
        self.is_active = True
        self.save(update_fields=['is_active'])
