
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = (
        'transaction_id',
        'user',
        'lend',
        'amount',
        'status',
        'created_at_humanize',
        'updated_at_humanize',

    )
    list_filter = (
        'status',
        'created_at',
        'updated_at',
    )
    search_fields = (
        'transaction_id',
        'user__username',
    )



    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'lend')
