
from django.db import models
from django.utils.translation import gettext_lazy as _
from lending.models import Lend
from django.contrib.humanize.templatetags.humanize import naturaltime
from users.models import User


class Payment(models.Model):
    user = models.ForeignKey(
        User,
        related_name='payments',
        on_delete=models.CASCADE,
        verbose_name=_('User'),
    )
    lend = models.OneToOneField(
        Lend,
        related_name='payment',
        on_delete=models.CASCADE,
        verbose_name=_('Lending record'),
    )
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name=_('Amount'),
        help_text=_('Amount payable (penalty based on days of delay))'),
    )
    STATUS_CHOICES = [
        ('pending',   _('Pending')),
        ('completed', _('Completed')),
        ('failed',    _('Failed')),
    ]
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name=_('Status'),
    )
    transaction_id = models.CharField(
        max_length=255,
        unique=True,
        verbose_name=_('Transaction ID'),
        help_text=_('Unique transaction ID from the payment gateway')
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('Created at')
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_('Updated at')
    )

    class Meta:
        verbose_name = _('Payment')
        verbose_name_plural = _('Payments')
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user.username} – {self.amount:,} – {self.get_status_display()}'

    def save(self, *args, **kwargs):
        if not self.amount:
            self.amount = self.lend.calculate_fine_delay
        super().save(*args, **kwargs)

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)
