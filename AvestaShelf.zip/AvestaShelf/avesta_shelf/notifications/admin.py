from django.contrib import admin
from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'recipient',
        'channel',
        'status',
        'send_at',
        'created_at_humanize',
    )
    list_filter = ('channel', 'status', 'send_at', 'created_at')
    search_fields = (
        'subject',
        'message',
    )
    autocomplete_fields = ('recipient',)
