from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime


User = get_user_model()

class Channel(models.TextChoices):
    EMAIL = "EMAIL", _("Email")
    SMS   = "SMS",   _("SMS")
    INAPP = "INAPP", _("In‑app")

class NotificationStatus(models.TextChoices):
    PENDING = "PENDING", _("Pending")
    SENT    = "SENT",    _("Sent")
    FAILED  = "FAILED",  _("Failed")
    READ    = "READ",    _("Read")

class Notification(models.Model):

    recipient = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="notifications",
        verbose_name=_("Recipient"),
    )
    subject   = models.CharField(max_length=200, blank=True, verbose_name=_("Subject"))
    message   = models.TextField(verbose_name=_("Message body"))
    channel   = models.CharField(
        max_length=10,
        choices=Channel.choices,
        default=Channel.EMAIL,
        verbose_name=_("Channel"),
    )
    status    = models.CharField(
        max_length=10,
        choices=NotificationStatus.choices,
        default=NotificationStatus.PENDING,
        verbose_name=_("Delivery status"),
    )
    send_at   = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name=_("Scheduled send time"),
        help_text=_("When to send this notification (null = immediately)"),
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Created at"))
    updated_at = models.DateTimeField(auto_now=True,  verbose_name=_("Updated at"))

    class Meta:
        verbose_name = _("Notification")
        verbose_name_plural = _("Notifications")
        ordering = ("-created_at",)

    def __str__(self):
        return f"{self.get_channel_display()} to {self.recipient} ({self.status})"

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)