from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime


class ReportType(models.TextChoices):
    BORROWING = "BORROWING", _("Borrowing activity")
    OVERDUE = "OVERDUE", _("Overdue & fines")
    POPULARITY = "POPULARITY", _("Book popularity")
    COMMUNITY = "COMMUNITY", _("Community engagement")
    CUSTOM = "CUSTOM", _("Custom ad‑hoc query")


class Report(models.Model):
    title = models.CharField(max_length=150, verbose_name=_("Title"))
    type = models.CharField(max_length=15, choices=ReportType.choices)
    creator = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="created_reports")
    file = models.FileField(upload_to="reports/", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))


    class Meta:
        verbose_name = _("Report")
        verbose_name_plural = _("Reports")


    def __str__(self):
        return f"{self.title} ({self.get_type_display()})"


    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)


    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)
