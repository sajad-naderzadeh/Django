from django.contrib import admin
from .models import (
    Community,
    CommunityMember,
    CommunityPost,
    CommunityPostLike,
    CommunityPostComment
)


# Register your models here.


class CommunityMemberInline(admin.TabularInline):
    model = CommunityMember
    extra = 1


class CommunityPostInline(admin.TabularInline):
    model = CommunityPost
    extra = 1


class CommunityPostLikeInline(admin.TabularInline):
    model = CommunityPostLike
    extra = 1


class CommunityPostCommentInline(admin.TabularInline):
    model = CommunityPostComment
    extra = 1


@admin.register(Community)
class CommunityAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'thumbnail_tag', 'slug', 'members_count', 'posts_count', 'updated_at_humanize',
                    'updated_at_humanize')
    list_display_links = ('id', 'title',)
    list_filter = ('updated_at', 'updated_at')
    search_fields = ('title', 'description', 'slug')
    inlines = (CommunityMemberInline, CommunityPostInline)


@admin.register(CommunityMember)
class CommunityMemberAdmin(admin.ModelAdmin):
    list_display = ('id', 'community', 'user', 'updated_at_humanize', 'updated_at_humanize')
    list_display_links = ('id', 'community')
    list_filter = ('created_at', 'updated_at', 'community')
    search_fields = ('community__title', 'community__description')


@admin.register(CommunityPost)
class CommunityPostAdmin(admin.ModelAdmin):
    list_display = ('id', 'community', 'thumbnail_tag', 'author', 'is_published', 'likes_count', 'comments_count',
                    'updated_at_humanize', 'updated_at_humanize')
    list_display_links = ('id', 'community')
    list_filter = ('updated_at', 'updated_at', 'is_published', 'community', 'author')
    search_fields = ('community__title', 'community__description', 'title', 'slug', 'description',)
    inlines = (CommunityPostLikeInline, CommunityPostCommentInline)


@admin.register(CommunityPostLike)
class CommunityPostLikeAdmin(admin.ModelAdmin):
    list_display = ('id', 'community_post', 'user', 'created_at_humanize', 'updated_at_humanize')
    list_display_links = ('id', 'community_post')
    list_filter = ('updated_at', 'updated_at', 'community_post', 'user')
    search_fields = ('community_post__title', 'community_post__description')


@admin.register(CommunityPostComment)
class CommunityPostCommentAdmin(admin.ModelAdmin):
    list_display = ('id', 'community_post', 'user', 'comment', 'created_at_humanize', 'updated_at_humanize')
    list_display_links = ('id', 'community_post')
    list_filter = ('updated_at', 'updated_at', 'community_post', 'user')
    search_fields = ('community_post__title', 'community_post__description', 'comment')
