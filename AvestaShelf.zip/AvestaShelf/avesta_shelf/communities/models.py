from django.contrib.auth import get_user_model
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime
from django.utils.html import format_html

User = get_user_model()


# Create your models here.


class Community(models.Model):
    title = models.CharField(max_length=255, unique=True, verbose_name=_('Title'))
    slug = models.SlugField(max_length=255, unique=True, verbose_name=_('Slug'))
    description = models.TextField(blank=True, verbose_name=_('Description'))
    thumbnail = models.ImageField(upload_to="communities/thumbnail/", verbose_name=_('Thumbnail'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Community')
        verbose_name_plural = _('Communities')

    def __str__(self):
        return self.title

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def thumbnail_tag(self):
        if self.thumbnail:
            url = self.thumbnail.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    thumbnail_tag.fget.short_description = _('Thumbnail')

    @property
    def members(self):
        return self.community_members.all()

    @property
    def members_count(self):
        return self.community_members.count()

    @property
    def posts(self):
        return self.community_posts.all()

    @property
    def posts_count(self):
        return self.community_posts.count()


class CommunityMember(models.Model):
    community = models.ForeignKey(Community, related_name='community_members', on_delete=models.CASCADE,
                                  verbose_name=_('Community'))
    user = models.ForeignKey(User, related_name='community_members', on_delete=models.CASCADE, verbose_name=_('User'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Community Member')
        verbose_name_plural = _('Community Members')
        unique_together = (('community', 'user'),)

    def __str__(self):
        return f'{self.community} - {self.user}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)


class CommunityPost(models.Model):
    community = models.ForeignKey(Community, related_name='community_posts', on_delete=models.CASCADE,
                                  verbose_name=_('Community'))
    author = models.ForeignKey(User, related_name='community_posts', on_delete=models.CASCADE,
                               verbose_name=_('Author'))
    title = models.CharField(max_length=255, verbose_name=_('Title'))
    slug = models.SlugField(max_length=255, unique=True, verbose_name=_('Slug'))
    description = models.TextField(verbose_name=_('Description'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))
    is_published = models.BooleanField(default=True, verbose_name=_('Is Published'))
    thumbnail = models.ImageField(upload_to="communities/community_posts/thumbnail/", verbose_name=_('Thumbnail'))

    class Meta:
        verbose_name = _('Community Post')
        verbose_name_plural = _('Community Posts')

    def __str__(self):
        return self.title

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def thumbnail_tag(self):
        if self.thumbnail:
            url = self.thumbnail.url
            return format_html(
                '<a target="_blank" href={}><img src="{}" width="60" height="60" style="object-fit:contain;" /></a>',
                url, url)
        return "-"

    thumbnail_tag.fget.short_description = _('Thumbnail')

    @property
    def likes(self):
        return self.community_post_likes.all()

    @property
    def likes_count(self):
        return self.community_post_likes.count()

    @property
    def comments(self):
        return self.community_post_comments.all()

    @property
    def comments_count(self):
        return self.community_post_comments.count()


class CommunityPostLike(models.Model):
    community_post = models.ForeignKey(CommunityPost, related_name='community_post_likes', on_delete=models.CASCADE,
                                       verbose_name=_('Community Post'))
    user = models.ForeignKey(User, related_name='community_post_likes', on_delete=models.CASCADE,
                             verbose_name=_('User'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Community Post Like')
        verbose_name_plural = _('Community Post Likes')
        unique_together = (('community_post', 'user'),)

    def __str__(self):
        return f'{self.community_post} - {self.user}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)


class CommunityPostComment(models.Model):
    community_post = models.ForeignKey(CommunityPost, related_name='community_post_comments', on_delete=models.CASCADE,
                                       verbose_name=_('Community Post'))
    user = models.ForeignKey(User, related_name='community_post_comments', on_delete=models.CASCADE,
                             verbose_name=_('User'))
    comment = models.TextField(verbose_name=_('Comment'))
    reply_to = models.ForeignKey('self', related_name='replies', on_delete=models.CASCADE, blank=True, null=True, verbose_name=_('Reply To'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))

    class Meta:
        verbose_name = _('Community Post Like')
        verbose_name_plural = _('Community Post Likes')

    def __str__(self):
        return f'{self.community_post} - {self.user}'

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)
