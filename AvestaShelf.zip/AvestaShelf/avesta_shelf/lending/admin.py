from django.contrib import admin

from .models import Lend


# Register your models here.


@admin.register(Lend)
class LendAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'book', 'is_returned', 'must_return_at_humanize', 'calculate_delay',
                    'calculate_fine_delay_display', 'created_at_humanize', 'updated_at_humanize',)
    list_display_links = ('id', 'user', 'book')
    list_filter = (
        'created_at',
        'updated_at',
        'must_return_at',
        'is_returned',
        'user',
        'book'
    )
    search_fields = ('book__title', 'book__description', 'book__isbn')
