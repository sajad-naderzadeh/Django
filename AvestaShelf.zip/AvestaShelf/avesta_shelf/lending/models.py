from datetime import timedelta
from django.utils import timezone
from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from django.contrib.humanize.templatetags.humanize import naturaltime
from django.conf import settings

from books.models import Book

User = get_user_model()


# Create your models here.


class Lend(models.Model):
    user = models.ForeignKey(User, related_name='lendings', on_delete=models.CASCADE, verbose_name=_('User'))
    book = models.ForeignKey(Book, related_name='lendings', on_delete=models.CASCADE, verbose_name=_('Book'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Created at'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('Updated at'))
    must_return_at = models.DateTimeField(blank=True, null=False, verbose_name=_('Must return at'))
    return_at = models.DateTimeField(blank=True, null=True, verbose_name=_('Return at'))
    is_returned = models.BooleanField(default=False, verbose_name=_('Is returned'))

    class Meta:
        verbose_name = _('Lend')
        verbose_name_plural = _('Lends')

    def __str__(self):
        return f'{self.user} - {self.book}'

    def save(self, *args, **kwargs):
        if self.must_return_at is None:
            self.must_return_at = timezone.now() + timedelta(days=getattr(settings, 'LEND_DURATION_IN_DAYS', 7))
        super().save(*args, **kwargs)

    @property
    def created_at_humanize(self):
        return naturaltime(self.created_at)

    @property
    def updated_at_humanize(self):
        return naturaltime(self.updated_at)

    @property
    def must_return_at_humanize(self):
        return naturaltime(self.must_return_at)

    def user_returned_book(self):
        self.is_returned = False
        self.return_at = timezone.now()
        self.save()

    @property
    def calculate_delay(self):
        now = timezone.now()
        # If we’re still within the allowed window, no delay:
        if now <= self.must_return_at:
            return 0

        # Compute the timedelta past due
        if self.is_returned:
            overdue_timedelta = self.return_at - self.must_return_at
        else:
            overdue_timedelta = now - self.must_return_at

        # Return only whole days
        return overdue_timedelta.days
    calculate_delay.fget.short_description = _('Delay in days')

    @property
    def calculate_fine_delay(self):
        return self.calculate_delay * getattr(settings, 'LEND_FINE_PER_DAYS', 15000)
    calculate_fine_delay.fget.short_description = _('Fine delay')

    @property
    def calculate_fine_delay_display(self):
        return "{:,}".format(self.calculate_fine_delay)
    calculate_fine_delay_display.fget.short_description = _('Fine delay')
